<?php $__env->startSection('title','Listado de caballos'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
    	<h1>
    		Listado de caballos
    	</h1>
    	<a href="<?php echo e(route('admin.caballos.create')); ?>" class="btn btn-primary">Agregar Caballo</a>
    	<hr>

    	<?php if(count($horses) > 0): ?>
    	<div class="col-xs-6">
			<table class="table table-bordered">
				<thead>
					<tr>
						<th>ID</th>
						<th>Nombre</th>
						<th>Actions</th>
					</tr>
				</thead>
				<tbody>
				<?php foreach($horses as $horse): ?>
					<tr>					
						<td><?php echo e($horse->id); ?></td>
						<td><?php echo e($horse->nombre); ?></td>	
						<td>
							<a href="#" data-horseid="<?php echo e($horse->id); ?>" onclick="return confirm('Estas seguro?');" class="btn btn-danger btn-delete-horse"><i class="fa fa-trash"></i></a>
							<a href="<?php echo e(route('admin.caballos.edit',$horse->id)); ?>" class="btn btn-warning"><i class="fa fa-pencil"></i></a>
						</td>

					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php else: ?>
			<h4>No hay caballos. Porfavor, agregue alguno.</h4>
		<?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('front-js'); ?>
<script>
    $('.btn-delete-horse').on('click', function(e) {
        var myThis = $(this).parent().parent();
        var dataId = $(this).data('horseid');

        $.ajax({
            url: '<?php echo e(url('/admin/caballos/destroyHorse')); ?>' + '/' + dataId,
            type: 'DELETE',
            data:{_token:token,id:dataId},
            success: function(msg) {
                console.log(msg['msg']);
                
                $(myThis).fadeOut(250);
            }
        });
    });	
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>