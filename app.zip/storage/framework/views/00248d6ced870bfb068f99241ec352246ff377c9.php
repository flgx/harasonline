<?php $__env->startSection('title','Editar Categoria'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
	    <div class="col-lg-12">
	    <h1>Editar Categoria</h1>
	    <hr>
	    	<?php echo Form::open(['route' => ['admin.categorias.update',$category->id],'method' => 'PUT']); ?>

	    		<div class="form-group">
	    			<?php echo Form::label('nombre','Nombre'); ?>

	    			<?php echo Form::text('nombre', $category->nombre,['class'=> 'form-control','placeholder'=>'Nombre Caballo','required']); ?>

	    		</div>
	    		<div class="form-group">
	    			<?php echo Form::submit('Editar Caballo',['class'=>'btn btn-primary']); ?>

	    		</div>
	    	<?php echo Form::close(); ?>

	    </div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>