<?php $__env->startSection('title','Agregar Categoria'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
	    <div class="col-lg-12">
	    <h1>Agregar Categoria</h1>
	    <hr>
	    	<?php echo Form::open(['route' => 'admin.categorias.store','method' => 'POST']); ?>

	    		<div class="form-group">
	    			<?php echo Form::label('nombre','Nombre'); ?>

	    			<?php echo Form::text('nombre', null,['class'=> 'form-control','placeholder'=>'Nombre Caballo','required']); ?>

	    		</div>
	    		<div class="form-group">
	    			<?php echo Form::submit('Agregar Caballo',['class'=>'btn btn-primary']); ?>

	    		</div>
	    	<?php echo Form::close(); ?>

	    </div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>