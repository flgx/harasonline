<?php $__env->startSection('title','Listado Categorias'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
    	<h1>Listado Categorias</h1>
    	<div>
    		<a class="btn btn-primary" href="<?php echo e(route('admin.categorias.create')); ?>">
    			Agregar Categoria
    		</a>
    	</div>
    	<hr>
    	<div class="col-xs-6">
			<table class="table table-bordered">
				<thead>
					<tr>
						<th>ID</th>
						<th>Nombre</th>
						<th>Actions</th>
					</tr>
				</thead>
				<tbody>
				<?php foreach($categories as $category): ?>
					<tr>					
						<td><?php echo e($category->id); ?></td>
						<td><?php echo e($category->nombre); ?></td>	
						<td>
							<a href="#" onclick="return confirm('Estas seguro?');" data-categoryid="<?php echo e($category->id); ?>" class="btn btn-danger btn-delete-category">
								<i class="fa fa-trash"></i>
							</a>
							<a href="<?php echo e(route('admin.categorias.edit',$category->id)); ?>" class="btn btn-warning">
								<i class="fa fa-pencil"></i>
							</a>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('front-js'); ?>
<script>
    $('.btn-delete-category').on('click', function(e) {
        var myThis = $(this).parent().parent();
        var dataId = $(this).data('categoryid');
        $.ajax({
            url: '<?php echo e(url('/admin/categorias/destroyCategory')); ?>' + '/' + dataId,
            type: 'DELETE',
            data:{_token:token,id:dataId},
            success: function(msg) {
                console.log(msg['msg']);
                
                $(myThis).fadeOut(250);
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>