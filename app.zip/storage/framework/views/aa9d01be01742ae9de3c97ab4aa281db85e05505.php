<!DOCTYPE html>
<html lang="es">
   <head>
      <meta charset="utf-8">
      <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
   </head>
   <body>
     <h2>Email remitente:</h2>
     <p><?php echo e($email); ?></p>
     <h2>Telefono:</h2>
     <p><?php echo e($phone); ?></p>
     <h2>Mensaje:</h2>
     <p><?php echo e($consulta); ?></p>
   </body>
</html>