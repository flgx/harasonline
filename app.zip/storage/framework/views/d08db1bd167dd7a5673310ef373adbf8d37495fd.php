<?php $__env->startSection('title','Crear Caballo'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
	    <div class="col-lg-12">
	    <h1>Agregar Caballo</h1>
	    <hr>
	    	<?php echo Form::open(['route' => 'admin.caballos.store','method' => 'POST','files'=>'true']); ?>


	    		<div class="form-group">
	    			<?php echo Form::label('nombre','Nombre'); ?>

	    			<?php echo Form::text('nombre', null,['class'=> 'form-control','placeholder'=>'Nombre Caballo','required']); ?>

	    		</div>
	    		<div class="form-group">
	    			<?php echo Form::label('category_id','Categoria'); ?>

	    			<?php echo Form::select('category_id',$categories,null,array('class'=>'form-control')); ?>

	    		</div>
	    		<div class="form-group">
	    			<?php echo Form::label('edad','Edad'); ?>

	    			<?php echo Form::text('edad', null,['class'=> 'form-control','placeholder'=>'Edad del Caballo','required']); ?>

	    		</div>	    		
	    		<div class="form-group">
	    			<?php echo Form::label('padre','Padre'); ?>

	    			<?php echo Form::text('padre', null,['class'=> 'form-control','placeholder'=>'Padre del Caballo','required']); ?>

	    		</div>
	    		<div class="form-group">
	    			<?php echo Form::label('madre','Madre'); ?>

	    			<?php echo Form::text('madre', null,['class'=> 'form-control','placeholder'=>'Madre del Caballo','required']); ?>

	    		</div>
	    		<div class="form-group">
	    			<?php echo Form::label('ubicacion','Ubicacion'); ?>

	    			<?php echo Form::text('ubicacion', null,['class'=> 'form-control','placeholder'=>'Ubicacion del Caballo','required']); ?>

	    		</div>	    		
	    		<div class="form-group">
	    			<?php echo Form::label('sexo','Sexo'); ?>

	    			<?php echo Form::select('sexo',array('macho' => 'Macho', 'hembra' => 'Hembra'),null,array('class'=>'form-control')); ?>

	    		</div>
	    		<div class="form-group">
	    			<?php echo Form::label('descripcion','Descripcion'); ?>

                    <?php echo Form::textarea('descripcion', null,['class' => 'form-control','required']); ?>

	    		</div>
	    		<div class="form-group">
	    			<?php echo Form::label('video_url','Video Url'); ?>

	    			<?php echo Form::text('video_url', null,['class'=> 'form-control','placeholder'=>'Url de YouTube','required']); ?>

	    		</div>
	    		<div class="form-group">
	    			<?php echo Form::label('images','Imagenes'); ?>

                    <?php echo Form::file('images[]', array('multiple'=>true)); ?>

	    		</div>

	    		<div class="form-group">
	    			<?php echo Form::submit('Agregar Caballo',['class'=>'btn btn-primary']); ?>

	    		</div>

	    	<?php echo Form::close(); ?>

	    </div>
	</div>
<!-- /.row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>