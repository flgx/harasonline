<?php $__env->startSection('title','Editar Caballo'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
	    <div class="col-md-6">
		    <h1>Editar Caballo</h1>
		    <hr>
		    	<?php echo Form::open(['route' => ['admin.caballos.update',$horse->id],'method' => 'PUT','files'=>'true']); ?>


		    		<div class="form-group">
		    			<?php echo Form::label('nombre','Nombre'); ?>

		    			<?php echo Form::text('nombre', $horse->nombre,['class'=> 'form-control','placeholder'=>'Nombre Caballo','required']); ?>

		    		</div>
		    		<div class="form-group">
		    			<?php echo Form::label('categoria','Categoria'); ?>

		    			<?php echo Form::select('categoria', $categories, $horse->category->id,array('class'=>'form-control'));; ?>

		    		</div>		    		
		    		<div class="form-group">
		    			<?php echo Form::label('edad','Edad'); ?>

		    			<?php echo Form::text('edad', $horse->edad,['class'=> 'form-control','placeholder'=>'Edad del Caballo','required']); ?>

		    		</div>	    		
		    		<div class="form-group">
		    			<?php echo Form::label('padre','Padre'); ?>

		    			<?php echo Form::text('padre', $horse->padre,['class'=> 'form-control','placeholder'=>'Padre del Caballo','required']); ?>

		    		</div>
		    		<div class="form-group">
		    			<?php echo Form::label('madre','Madre'); ?>

		    			<?php echo Form::text('madre', $horse->madre,['class'=> 'form-control','placeholder'=>'Madre del Caballo','required']); ?>

		    		</div>
		    		<div class="form-group">
		    			<?php echo Form::label('ubicacion','Ubicacion'); ?>

		    			<?php echo Form::text('ubicacion', $horse->ubicacion,['class'=> 'form-control','placeholder'=>'Ubicacion del Caballo','required']); ?>

		    		</div>	    		
		    		<div class="form-group">
		    			<?php echo Form::label('sexo','Sexo'); ?>

		    			<?php echo Form::select('sexo',array('macho' => 'Macho', 'hembra' => 'Hembra'),$horse->sexo,array('class'=>'form-control')); ?>

		    		</div>
		    		<div class="form-group">
		    			<?php echo Form::label('descripcion','Descripcion'); ?>

	                    <?php echo Form::textarea('descripcion', $horse->descripcion,['class' => 'form-control','required']); ?>

		    		</div>
		    		<div class="form-group">
		    			<?php echo Form::label('video_url','Video'); ?>

		    			<?php echo Form::text('video_url', $horse->video_url,['class'=> 'form-control','placeholder'=>'Url de YouTube','required']); ?>

		    		</div>		
		    		<div class="form-group">
		    			<?php echo Form::label('images','Imagenes'); ?>

	                    <?php echo Form::file('images[]', array('multiple'=>true)); ?>

		    		</div>


		    		<div class="form-group">
		    			<?php echo Form::submit('Editar Caballo',['class'=>'btn btn-primary']); ?>

		    		</div>

		    	<?php echo Form::close(); ?>

	    </div>
	    <!-- Horse Images -->
	    <div class="col-md-6">
	    	<h1>Galeria de imágenes</h1>
		    <hr>
		    <?php if(count($horse->images) > 0): ?>	
		    	<?php
					$i=0;
				?>
				<?php foreach($horse->images as $image): ?>
				<div class="col-xs-12">
					<?php if($i==0){echo '<h1>Imágen principal:</h1> <hr>';} ?>
					<?php echo e(HTML::image('img/horses/thumbs/thumb_'.$image->nombre, '$horse->nombre')); ?>

					
					<p class="col-xs-12" style="padding-left:0px; margin-top:10px;">
						<a href="#" class="btn-delete btn btn-danger"  data-horse="<?php echo e($image->id); ?>"><i class="fa fa-trash fa-2x"></i></a>
					</p>
				</div>
				<hr>
				<?php $i++; ?>
				<?php endforeach; ?>
			<?php else: ?>
				<p>No hay imágenes. Por favor, agregue alguna.</p>	
			<?php endif; ?>   	
	    </div>
	</div>
<!-- /.row -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('front-js'); ?>
<script>
    $('.btn-delete').on('click', function(e) {
        var myThis = $(this).parent().parent();
        var dataId = $(this).data('horse');

        $.ajax({
            url: '<?php echo e(url('/admin/imagen/destroyImage')); ?>' + '/' + dataId,
            type: 'DELETE',
            data:{_token:token,id:dataId},
            success: function(msg) {
                console.log(msg['msg']);
                
                $(myThis).fadeOut(150);
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>