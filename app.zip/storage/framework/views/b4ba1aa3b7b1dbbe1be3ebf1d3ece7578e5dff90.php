<?php $__env->startSection('nav'); ?>
	<?php echo $__env->make('layouts.partials.navSingle', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<section id="productos" class="section section-padded">
		<div class="container">
			<div class="row text-center title">
				<h2>Todos nuestros productos</h2>
				<h4 class="light muted">Hacer click para ver más informacion de los pura sangre.</h4>
			</div>
			<div class="row services">
			<?php foreach($horses as $horse): ?>
			<a href="<?php echo e(route('horse.show',$horse->id)); ?>"></a>
				<div class="col-md-3">
					<div class="productos">
					<?php $myimage='';$i=0; ?>
					<?php foreach($horse->images as $image): ?>
						<?php
							if($i == 0){
								$myimage=$image->nombre;
							}							
							$i++;
						?>
					<?php endforeach; ?>
						<div>
							<img src="img/horses/thumbs/thumb_<?php echo e($myimage); ?>" alt="" class="img-responsive icon">
						</div>
						<h4 class="heading">
							<a  class="title-index" href="<?php echo e(route('horse.show',$horse->slug)); ?>"><?php echo e($horse->nombre); ?></a>
						</h4>
						<h4 class="heading plus fa fa-plus fa-2x"></h4>
						<div class="description">
							<ul>
								<li>Categoria: <?php echo e($horse->category->nombre); ?>.</li>
								<li>Sexo: <?php echo e($horse->sexo); ?>.</li>
								<li>Edad: <?php echo e($horse->edad); ?>.</li>
								<li>Madre: <?php echo e($horse->madre); ?>.</li>
								<li>Padre: <?php echo e($horse->padre); ?>.</li>
								<li>Ubicacion: <?php echo e($horse->ubicacion); ?>.</li>
							</ul>
							<p><?php echo e(str_limit($horse->descripcion,100)); ?></p>
						<a href="<?php echo e(route('horse.show',$horse->slug)); ?>">
							<button class="morebtn btn-primary">Ver Más</button>
						</a>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
			</div>
		</div>
		<div class="text-center">
			<?php echo $horses->render(); ?>

		</div>
		<div class="cut cut-bottom"></div>
	</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>